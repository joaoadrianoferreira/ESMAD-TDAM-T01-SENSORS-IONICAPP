
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-device-motion.Acceleration",
          "file": "plugins/cordova-plugin-device-motion/www/Acceleration.js",
          "pluginId": "cordova-plugin-device-motion",
        "clobbers": [
          "Acceleration"
        ]
        },
      {
          "id": "cordova-plugin-fingerprint-aio.Fingerprint",
          "file": "plugins/cordova-plugin-fingerprint-aio/www/Fingerprint.js",
          "pluginId": "cordova-plugin-fingerprint-aio",
        "clobbers": [
          "Fingerprint"
        ]
        },
      {
          "id": "cordova-plugin-device-motion.accelerometer",
          "file": "plugins/cordova-plugin-device-motion/www/accelerometer.js",
          "pluginId": "cordova-plugin-device-motion",
        "clobbers": [
          "navigator.accelerometer"
        ]
        },
      {
          "id": "cordova-plugin-geolocation.geolocation",
          "file": "plugins/cordova-plugin-geolocation/www/android/geolocation.js",
          "pluginId": "cordova-plugin-geolocation",
        "clobbers": [
          "navigator.geolocation"
        ]
        },
      {
          "id": "cordova-plugin-gyroscope.gyroscope",
          "file": "plugins/cordova-plugin-gyroscope/www/gyroscope.js",
          "pluginId": "cordova-plugin-gyroscope",
        "clobbers": [
          "navigator.gyroscope"
        ]
        },
      {
          "id": "cordova-plugin-gyroscope.Orientation",
          "file": "plugins/cordova-plugin-gyroscope/www/Orientation.js",
          "pluginId": "cordova-plugin-gyroscope",
        "clobbers": [
          "Orientation"
        ]
        },
      {
          "id": "cordova-plugin-geolocation.PositionError",
          "file": "plugins/cordova-plugin-geolocation/www/PositionError.js",
          "pluginId": "cordova-plugin-geolocation",
        "runs": true
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-device-motion": "2.0.1",
      "cordova-plugin-fingerprint-aio": "3.0.1",
      "cordova-plugin-geolocation": "4.0.2",
      "cordova-plugin-gyroscope": "0.1.4"
    };
    // BOTTOM OF METADATA
    });
    